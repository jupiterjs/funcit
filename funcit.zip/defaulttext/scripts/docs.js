//js funcit/defaulttext/scripts/doc.js

load('steal/rhino/steal.js');
steal.plugins("documentjs").then(function(){
	DocumentJS('funcit/defaulttext/defaulttext.html');
});