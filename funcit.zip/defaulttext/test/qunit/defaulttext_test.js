module("defaulttext");

test("defaulttext testing works", function(){
	ok(true,"an assert is run");
});