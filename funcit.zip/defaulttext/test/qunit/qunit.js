steal
  .plugins("funcunit/qunit", "funcit/defaulttext")
  .then("defaulttext_test");