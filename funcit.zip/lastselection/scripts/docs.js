//js funcit/lastselection/scripts/doc.js

load('steal/rhino/steal.js');
steal.plugins("documentjs").then(function(){
	DocumentJS('funcit/lastselection/lastselection.html');
});