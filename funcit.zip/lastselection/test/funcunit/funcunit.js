steal
 .plugins("funcunit")
 .then("lastselection_test");