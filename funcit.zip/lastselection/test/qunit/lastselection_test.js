module("lastselection");

test("lastselection testing works", function(){
	ok(true,"an assert is run");
});