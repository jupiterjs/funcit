steal
  .plugins("funcunit/qunit", "funcit/lastselection")
  .then("lastselection_test");