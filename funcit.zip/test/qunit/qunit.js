steal
  .plugins("funcunit/qunit", "funcit")
  .then("funcit_test");