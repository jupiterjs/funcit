module("funcit");

test("funcit testing works", function(){
	ok(true,"an assert is run");
});