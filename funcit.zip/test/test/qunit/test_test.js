module("test");

test("test testing works", function(){
	ok(true,"an assert is run");
});