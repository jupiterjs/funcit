steal
  .plugins("funcunit/qunit", "funcit/test")
  .then("test_test");