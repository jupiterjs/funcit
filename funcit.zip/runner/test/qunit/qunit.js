steal
  .plugins("funcunit/qunit", "funcit/runner")
  .then("runner_test");