module("runner");

test("runner testing works", function(){
	ok(true,"an assert is run");
});