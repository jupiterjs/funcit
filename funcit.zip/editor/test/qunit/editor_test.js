module("editor");

test("editor testing works", function(){
	ok(true,"an assert is run");
});