steal
  .plugins("funcunit/qunit", "funcit/editor")
  .then("editor_test");