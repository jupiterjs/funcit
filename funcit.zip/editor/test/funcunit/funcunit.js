steal
 .plugins("funcunit")
 .then("editor_test");