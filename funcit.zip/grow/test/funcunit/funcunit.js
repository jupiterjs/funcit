steal
 .plugins("funcunit")
 .then("grow_test");