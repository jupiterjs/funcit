module("grow");

test("grow testing works", function(){
	ok(true,"an assert is run");
});