steal
  .plugins("funcunit/qunit", "funcit/rowheight")
  .then("rowheight_test");