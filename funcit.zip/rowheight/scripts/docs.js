//js funcit/rowheight/scripts/doc.js

load('steal/rhino/steal.js');
steal.plugins("documentjs").then(function(){
	DocumentJS('funcit/rowheight/rowheight.html');
});